package com.example.learn.jwtAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthentication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
