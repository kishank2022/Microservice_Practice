package com.example.learn.jwtAuthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtAuthentication1Application {

	public static void main(String[] args) {
		SpringApplication.run(JwtAuthentication1Application.class, args);
	}

}
