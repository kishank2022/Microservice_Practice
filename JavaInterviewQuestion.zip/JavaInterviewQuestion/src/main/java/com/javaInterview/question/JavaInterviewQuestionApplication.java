package com.javaInterview.question;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaInterviewQuestionApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaInterviewQuestionApplication.class, args);
	}

}
