package com.unit.test.cases.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestCasesLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestCasesLearningApplication.class, args);
	}

}
