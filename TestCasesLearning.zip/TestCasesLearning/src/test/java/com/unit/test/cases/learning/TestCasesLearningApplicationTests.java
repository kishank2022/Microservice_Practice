package com.unit.test.cases.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCasesLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
