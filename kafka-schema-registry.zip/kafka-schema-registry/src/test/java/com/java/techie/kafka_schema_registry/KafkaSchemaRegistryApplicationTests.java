package com.java.techie.kafka_schema_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSchemaRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
