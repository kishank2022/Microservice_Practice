package com.insurance.policy.dto;




public class GetQuoteResponseDtoCoverDtlList {

	private String CoverDesc;
    private String Premium;
    private String Type;
	public GetQuoteResponseDtoCoverDtlList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GetQuoteResponseDtoCoverDtlList(String coverDesc, String premium, String type) {
		super();
		CoverDesc = coverDesc;
		Premium = premium;
		Type = type;
	}
	@Override
	public String toString() {
		return "GetQuoteResponseDtoCoverDtlList [CoverDesc=" + CoverDesc + ", Premium=" + Premium + ", Type=" + Type
				+ "]";
	}
	public String getCoverDesc() {
		return CoverDesc;
	}
	public void setCoverDesc(String coverDesc) {
		CoverDesc = coverDesc;
	}
	public String getPremium() {
		return Premium;
	}
	public void setPremium(String premium) {
		Premium = premium;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
    
    
    
}
