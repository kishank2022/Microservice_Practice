package com.insurance.policy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


public class GetQuoteResponseDto {

	private GetQuoteResponseDtoMessageResult MessageResult;
    private GetQuoteResponseDtoGetQuotResult GetQuotResult;
	public GetQuoteResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GetQuoteResponseDto(GetQuoteResponseDtoMessageResult messageResult,
			GetQuoteResponseDtoGetQuotResult getQuotResult) {
		super();
		MessageResult = messageResult;
		GetQuotResult = getQuotResult;
	}
	@Override
	public String toString() {
		return "GetQuoteResponseDto [MessageResult=" + MessageResult + ", GetQuotResult=" + GetQuotResult + "]";
	}
	public GetQuoteResponseDtoMessageResult getMessageResult() {
		return MessageResult;
	}
	public void setMessageResult(GetQuoteResponseDtoMessageResult messageResult) {
		MessageResult = messageResult;
	}
	public GetQuoteResponseDtoGetQuotResult getGetQuotResult() {
		return GetQuotResult;
	}
	public void setGetQuotResult(GetQuoteResponseDtoGetQuotResult getQuotResult) {
		GetQuotResult = getQuotResult;
	}
    
    
    
}
