package com.insurance.policy.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;


public class GetQuoteResponseDtoGetQuotResult {

	private String POL_SYS_ID;
    private String PROPOSAL_NO;
    private String VehicleIDV;
    private String ERROR_DESC;
    private String ERROR_CODE;
    private List<GetQuoteResponseDtoCoverDtlList> CoverDtlList;
	public GetQuoteResponseDtoGetQuotResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GetQuoteResponseDtoGetQuotResult(String pOL_SYS_ID, String pROPOSAL_NO, String vehicleIDV, String eRROR_DESC,
			String eRROR_CODE, List<GetQuoteResponseDtoCoverDtlList> coverDtlList) {
		super();
		POL_SYS_ID = pOL_SYS_ID;
		PROPOSAL_NO = pROPOSAL_NO;
		VehicleIDV = vehicleIDV;
		ERROR_DESC = eRROR_DESC;
		ERROR_CODE = eRROR_CODE;
		CoverDtlList = coverDtlList;
	}
	@Override
	public String toString() {
		return "GetQuoteResponseDtoGetQuotResult [POL_SYS_ID=" + POL_SYS_ID + ", PROPOSAL_NO=" + PROPOSAL_NO
				+ ", VehicleIDV=" + VehicleIDV + ", ERROR_DESC=" + ERROR_DESC + ", ERROR_CODE=" + ERROR_CODE
				+ ", CoverDtlList=" + CoverDtlList + "]";
	}
	public String getPOL_SYS_ID() {
		return POL_SYS_ID;
	}
	public void setPOL_SYS_ID(String pOL_SYS_ID) {
		POL_SYS_ID = pOL_SYS_ID;
	}
	public String getPROPOSAL_NO() {
		return PROPOSAL_NO;
	}
	public void setPROPOSAL_NO(String pROPOSAL_NO) {
		PROPOSAL_NO = pROPOSAL_NO;
	}
	public String getVehicleIDV() {
		return VehicleIDV;
	}
	public void setVehicleIDV(String vehicleIDV) {
		VehicleIDV = vehicleIDV;
	}
	public String getERROR_DESC() {
		return ERROR_DESC;
	}
	public void setERROR_DESC(String eRROR_DESC) {
		ERROR_DESC = eRROR_DESC;
	}
	public String getERROR_CODE() {
		return ERROR_CODE;
	}
	public void setERROR_CODE(String eRROR_CODE) {
		ERROR_CODE = eRROR_CODE;
	}
	public List<GetQuoteResponseDtoCoverDtlList> getCoverDtlList() {
		return CoverDtlList;
	}
	public void setCoverDtlList(List<GetQuoteResponseDtoCoverDtlList> coverDtlList) {
		CoverDtlList = coverDtlList;
	}
    
    
}
