package com.insurance.policy.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


public class GetQuoteResponseDtoMessageResult {

	private String Result;
    private String ErrorMessage;
    private String SuccessMessage;
	public GetQuoteResponseDtoMessageResult(String result, String errorMessage, String successMessage) {
		super();
		Result = result;
		ErrorMessage = errorMessage;
		SuccessMessage = successMessage;
	}
	public GetQuoteResponseDtoMessageResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "GetQuoteResponseDtoMessageResult [Result=" + Result + ", ErrorMessage=" + ErrorMessage
				+ ", SuccessMessage=" + SuccessMessage + "]";
	}
	public String getResult() {
		return Result;
	}
	public void setResult(String result) {
		Result = result;
	}
	public String getErrorMessage() {
		return ErrorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}
	public String getSuccessMessage() {
		return SuccessMessage;
	}
	public void setSuccessMessage(String successMessage) {
		SuccessMessage = successMessage;
	}
    
    
}
