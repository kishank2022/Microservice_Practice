package com.learning.kafka.deliveryPartner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryPartnerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
