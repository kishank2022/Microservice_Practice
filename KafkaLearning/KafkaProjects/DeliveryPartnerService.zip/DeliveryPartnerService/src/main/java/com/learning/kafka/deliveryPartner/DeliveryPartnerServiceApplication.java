package com.learning.kafka.deliveryPartner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryPartnerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryPartnerServiceApplication.class, args);
	}

}
