package com.learning.kafka.endUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndUserServiceApplication.class, args);
	}

}
