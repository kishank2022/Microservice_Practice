package com.code.with.durgesh.schedular.schedular_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedularSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedularSpringBootApplication.class, args);
	}

}
