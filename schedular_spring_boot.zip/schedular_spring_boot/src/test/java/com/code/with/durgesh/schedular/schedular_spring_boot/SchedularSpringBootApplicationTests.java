package com.code.with.durgesh.schedular.schedular_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedularSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
